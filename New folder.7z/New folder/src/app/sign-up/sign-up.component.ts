import { Component, OnInit } from '@angular/core';
import {FormGroup,Validators,FormControl} from '@angular/forms';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  signUpForm;
   userName: FormControl;
  email: FormControl;
  phoneNumber: FormControl;
  password: FormControl;
  confirmPassword: FormControl;
  gender: FormControl;
  dateOfBirth:FormControl;
  passwordCheck;
  confirmPasswordError:boolean=true;
  constructor() { }

  ngOnInit() {
    this.signUpFormValidations();
    this.signUpFormIntialization();
  }

  signUpFormValidations(){
    this.userName = new FormControl("", Validators.compose([
      Validators.required,Validators.pattern("[a-zA-Z0-9 ]{6,15}")]));
    this.email = new FormControl("", Validators.compose([
      Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]));
    this.phoneNumber = new FormControl("", Validators.compose([
      Validators.required,Validators.pattern('[9/8/7/6][0-9]{9}')]));
    this.password = new FormControl("", [
      Validators.required, Validators.pattern("(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,15}")
    ]);
    this.confirmPassword = new FormControl("", Validators.compose([
      Validators.required]));
    this.gender = new FormControl("", [
      Validators.required
    ]);
    this.dateOfBirth = new FormControl("", [
      Validators.required
    ]);
  }

  signUpFormIntialization(){
    this.signUpForm = new FormGroup({
      userName: this.userName,
      email: this.email,
      phoneNumber: this.phoneNumber,
      password: this.password,
      confirmPassword: this.confirmPassword,
      gender: this.gender,
      dateOfBirth : this.dateOfBirth
    });
  }

  ConfirmPasswordCheck(confirmPassword){
    if(this.passwordCheck === confirmPassword){
      this.confirmPasswordError = false;
    }
    else
    {
      this.confirmPasswordError = true;
    }
  }
  signUpSubmit(){
    console.log("sdfaf");
    console.log(this.dateOfBirth.value);
  }

}
