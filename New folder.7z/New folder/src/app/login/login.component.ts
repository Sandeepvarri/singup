import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  emailid:string;
  password:string;
  constructor() { }
  formsubmit(){
    alert("username:" +this.emailid+"<br/>Password"+ this.password);
  }

  ngOnInit() {
  }

}
